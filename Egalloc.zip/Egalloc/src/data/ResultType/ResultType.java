package data.ResultType;

public enum ResultType {
	success, failure
}
