package Server;

public class Item {
    private String link;

    public String getLink() {
        return link;
    }

}
