package Server;

public class APIResponse {
    private Item[] items;

    public Item[] getItems() {
        return items;
    }
}
